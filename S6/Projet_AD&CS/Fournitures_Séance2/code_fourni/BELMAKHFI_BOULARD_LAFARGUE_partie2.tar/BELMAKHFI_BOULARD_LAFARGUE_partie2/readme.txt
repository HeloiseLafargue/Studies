Autres fichiers Matlab :

- test_v12 : pour tester la méthode power_12

- test_matrices : pour afficher les spectres des différents types de matrices
