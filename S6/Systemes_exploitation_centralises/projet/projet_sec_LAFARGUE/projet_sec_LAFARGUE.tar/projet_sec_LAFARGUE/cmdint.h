#ifndef CMDINT_H
#define CMDINT_H

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <string.h>
#include <stddef.h>
#include "processus.h"

// QUESTION 6
// Gestion des processus lancés depuis le shell

// Procédure pour chaque commande interne
void lj(Liste_Processus* liste_p);
void sj(int ident, Liste_Processus* liste_p);
void bg(int ident, Liste_Processus* liste_p, pid_t* pid_avant_plan);
void fg(int ident, Liste_Processus* liste_p, pid_t* pid_avant_plan);

#endif
