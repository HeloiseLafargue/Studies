#include "cmdint.h"

// QUESTION 6
// Gestion des processus lancés depuis le shell


// fj donne la liste des processus lancés depuis le minishell et non encore terminés avec leur identifiant propre au minishell, leur pid, leur état (actif/suspendu) et la  ligne de commande lancée
void lj(Liste_Processus* liste_p) {
	for(int i = 0; i < liste_p->taille; i++) {
		Processus p = *(liste_p->l+i);
		char* etatstr;
		if (p.etat == 0) {
			etatstr = "actif";
		} else {
			etatstr = "suspendu";
		}
		printf("%d  %d  %s  %s\n", p.ident, p.pid, etatstr, p.commande);
	}
}

// sj permet de suspendre un job
void sj(int ident, Liste_Processus* liste_p) {
	pid_t pid = idToPid(ident, liste_p);
	kill(pid, SIGSTOP);
}

// bg permet de reprendre en arrière-plan un job suspendu
void bg(int ident, Liste_Processus* liste_p, pid_t* pid_avant_plan) {
	pid_t pid = idToPid(ident, liste_p);
	// Attente de l'avant plan
	while(*pid_avant_plan > 0) {
		pause();
	}
	kill(pid, SIGCONT);
}

// fg permet de poursuivre en avant-plan un job suspendu ou en arrière-plan
void fg(int ident, Liste_Processus* liste_p, pid_t* pid_avant_plan) {
	pid_t pid = idToPid(ident, liste_p);
	*pid_avant_plan = pid;
	kill(pid, SIGCONT);
	// Attente de l'avant plan
	while(*pid_avant_plan > 0) {
		pause();
	}
}

