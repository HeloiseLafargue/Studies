#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* primitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <sys/wait.h> /* wait */
#include <string.h> /* pour utiliser la commande strcmp */
#include "readcmd.h" 
#include <stdbool.h>
#include <stddef.h>
#include <errno.h>
#include <malloc.h>
#include <fcntl.h>
#include <assert.h>
#include "cmdint.h"
#include "processus.h"
#include "cmdint.c"
#include "processus.c"

#define N 10

typedef struct cmdline cmdline;
const char* CMDINT[] = {"cd", "exit", "lj", "sj", "bg", "fg"};

void suivi_fils (int sign);
void ctrlC(int sign);
void ctrlZ(int sign);
void initialiser_liste(Liste_Processus* l);
bool est_cmd_int(cmdline* cmd);
void traiter_cmdint(cmdline* cmd, Liste_Processus* l);
void executer_fils(cmdline* cmd, int fils, pid_t pidFils);

Liste_Processus liste_p;
pid_t pid_avant_plan;

int main(int argc, char *argv[]) {
	
	initialiser_liste(&liste_p);
	
	int err;

	struct sigaction nv_action;
	sigemptyset(&nv_action.sa_mask);
	nv_action.sa_flags = 0;
	nv_action.sa_handler = suivi_fils;
	sigaction(SIGCHLD, &nv_action, NULL);
    
    // QUESTION 7
    // Un processus lancé depuis le minishell pourra être suspendu par la frappe de CTR_Z
	nv_action.sa_handler = ctrlZ;
	sigaction(SIGTSTP, &nv_action, NULL);
	
    // QUESTION 8
    // Terminaison du processus en avant plan sans provoquer la terminaison du shell
	nv_action.sa_handler = ctrlC;
	sigaction(SIGINT, &nv_action, NULL);
	
	while(1) {
		// QUESTION 1
		printf("sh-3.2$");
		cmdline* cmd;
		do {	
			cmd = readcmd();
		} while(cmd == NULL);

		if (cmd->err != NULL) {
			printf("Erreur : %s", cmd->err);
		}

		if(*cmd->seq != NULL) {
		
			// QUESTION 6
			// Traitement des commandes internes
			if (est_cmd_int(cmd)) {
				traiter_cmdint(cmd, &liste_p);
			// Traitement autre
			} else {

				// Initialiser les tubes
				int nb_tubes = 0;
	            while ((cmd->seq[nb_tubes]) != NULL) {
		                nb_tubes++;
	            }
				int nb = nb_tubes - 1;
				
				int p[nb+1][2];
				for (int i = 0; i <= nb; i++) {
					err = pipe(p[i]);
					if (err == -1) { perror("Erreur pipes"); exit(6); }
				}

				// Lancer les fils nécessaires à l'execution
				for (int fils = 0; fils < nb; fils++) {
					pid_t pidFils = fork();
					if (pidFils == -1) {
						perror("Erreur fils"); 
						exit(1); 
					} else if (pidFils == 0) {

						// Fermer les tubes non utilisés
						err = close(p[fils][0]);
						if (err == -1) { perror("Erreur close"); exit(7); }
						if (fils + 1 < nb) {
							err = close(p[fils+1][1]);
							if (err == -1) { perror("Erreur close"); exit(7); }
						}
						for (int i = 0; i < nb; i++) {
							if ((i != fils) && (i != fils + 1)) {
								err = close(p[i][0]);
								if (err == -1) { perror("Erreur close"); exit(7); }
								err = close(p[i][1]);
								if (err == -1) { perror("Erreur close"); exit(7); }
							}
						}
						// Fermer les tubes utilisés
						err = close(p[fils][1]);
						if (err == -1) { perror("Erreur close"); exit(7); }
						if (fils + 1 < nb) {
							err = close(p[fils+1][0]);
							if (err == -1) { perror("Erreur close"); exit(7); }
						}
					}
					executer_fils(cmd, fils, pidFils);
				}

				// Execution de la dernière commande
				pid_t pid = fork();
				executer_fils(cmd, nb, pid);

				for (int i = 1; i < nb; i++) {
					err = close(p[i][0]);
					if (err == -1) { perror("Erreur close"); exit(7); }					
				}
			}
		}
	}
	return EXIT_SUCCESS;
}

void suivi_fils (int sig) {
    int etat_fils, pid_fils;
    do {
    // Traitement de la terminaison des fils au niveau du traitant
        pid_fils = (int) waitpid(-1, &etat_fils, WNOHANG | WUNTRACED | WCONTINUED);
        if ((pid_fils == -1) && (errno != ECHILD)) {

            perror("waitpid");
            exit(EXIT_FAILURE);
        } else if (pid_fils > 0) {
            if (WIFCONTINUED(etat_fils)) {
		// Changer l'etat dans la liste des processus en actif
			changer_etat(&liste_p, pid_fils, ACTIF);
		
            } else if (WIFSTOPPED(etat_fils)) {
		// Changer l'etat dans la liste des processus en suspendu
			changer_etat(&liste_p, pid_fils, SUSPENDU);
			pid_avant_plan = 0;

            } else if (WIFSIGNALED(etat_fils)) {
		// Supprimer de la liste des processus
			supprimer(&liste_p, pid_fils);
			pid_avant_plan = 0;

            } else if (WIFEXITED(etat_fils)) {
		// Supprimer de la liste des processus
			supprimer(&liste_p, pid_fils);
			pid_avant_plan = 0;
            }
        }
    } while (pid_fils > 0);
}


// Initialiser la liste des processus 
void initialiser_liste(Liste_Processus* l) {
	l->capacite = N;
	l->taille = 0;
	l->l = malloc(N*sizeof(Processus));	
}

// Vraie si la commande est une commande interne
bool est_cmd_int(cmdline* cmd) {
	bool res = false;
	for (int i=0; i < 6; i++) {
		if (strcmp(cmd->seq[0][0], CMDINT[i]) == 0) {
			res = true;
		}
	}
	return res;
}


// Traitement commande interne 
void traiter_cmdint(cmdline* cmd, Liste_Processus* l) {
	
	// QUESTION 4
	// Commandes internes exécutées directement par l’interpréteur sans lancer de processus fils :
	// cd et exit 
	if (strcmp(cmd->seq[0][0], "cd") == 0) {
		chdir(cmd->seq[0][1]);
	}
	if (strcmp(cmd->seq[0][0], "exit") == 0) {
		exit(0);
	}
	
	// QUESTION 6
	// Pour gérer les processus lancés depuis le shell : 
	// lj (list jobs), sj (stop job), bg (background), fg (foreground) 
	if (strcmp(cmd->seq[0][0], "lj") == 0) {
		lj(l);
	}
	if (strcmp(cmd->seq[0][0], "sj") == 0) {
		int ident = atoi(cmd->seq[0][1]);
		if (est_ident(l, ident)) {
			sj(ident, l);
		} else { printf("Non conforme\n"); }
	}
	if (strcmp(cmd->seq[0][0], "bg") == 0) {
		int ident = strtol(cmd->seq[0][1],NULL,0);
		if (est_ident(l, ident)) {
			bg(ident, l, &pid_avant_plan);
		} else { printf("Non conforme\n"); }
	}
	if (strcmp(cmd->seq[0][0], "fg") == 0) {
		int ident = strtol(cmd->seq[0][1],NULL,0);
		if (est_ident(l, ident)) {
			fg(ident, l, &pid_avant_plan);
		} else { printf("Non conforme\n"); }
	}
}

// Traitement commande non-interne 
void executer_fils(cmdline* cmd, int fils, pid_t pidFils) {

	if (pidFils < 0) {
		perror("Erreur fork");
		exit(1);
	} else if (pidFils == 0) {
		
		signal(SIGINT, SIG_IGN);
		signal(SIGTSTP, SIG_IGN);

		int errExec = execvp(cmd->seq[fils][0], cmd->seq[fils]);
		if (errExec == -1) {
			perror("Erreur d'éxécution");
			exit(2);
		}
	} else {
		// Ajout du processus à la liste
		char* ligne_cmd;
		ligne_cmd = malloc(strlen(cmd->seq[fils][0])+1);
		strcpy(ligne_cmd, cmd->seq[fils][0]);
		Processus p = nv_processus(&liste_p, pidFils, ACTIF, ligne_cmd);
		ajouter(&liste_p, p);
		
		// Commande en arriere-plan
		if (cmd->backgrounded != NULL) {
			pid_avant_plan = 0;				
		}
		else {
			pid_avant_plan = pidFils;
		}

		// Attente avant-plan 
		while (pid_avant_plan > 0) {
			pause();
		}
	}
}

// QUESTION 7
// Un processus lancé depuis le minishell pourra être suspendu par la frappe de CTR_Z
// handler pour CTRL+Z
void ctrlZ(int sign) {
	if (pid_avant_plan > 0) {
		printf("\nSuspension du fils en avant plan %d\n", pid_avant_plan);
		kill(pid_avant_plan, SIGSTOP);
	}
}

// QUESTION 8
// Terminaison du processus en avant plan sans provoquer la terminaison du shell
// handler pour CTRL+C
void ctrlC(int sign) {
	if (pid_avant_plan > 0) {
		printf("\nTerminaison du fils en avant plan %d\n", pid_avant_plan);
		kill(pid_avant_plan, SIGKILL);
	}
}

