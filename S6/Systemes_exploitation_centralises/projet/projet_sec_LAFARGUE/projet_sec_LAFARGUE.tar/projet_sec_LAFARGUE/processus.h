#ifndef PROCESSUS_H
#define PROCESSUS_H

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <string.h>
#include <stddef.h>

//Structures

enum Etat_Processus { ACTIF, SUSPENDU };
typedef enum Etat_Processus Etat_Processus;

struct Processus {
	int ident;
	pid_t pid;
	Etat_Processus etat;
	char* commande;
};
typedef struct Processus Processus;

struct Liste_Processus {
	Processus* l;
	int taille;
	int capacite;
};
typedef struct Liste_Processus Liste_Processus;

//Procédures 

// Créer un nouveau processus
Processus nv_processus(Liste_Processus* liste_p, pid_t pid, Etat_Processus etat, char* seq);
// Changer un identifiant en pid
pid_t idToPid(int ident, Liste_Processus* liste_p);
// Changer un pid en identifiant 
int pidToId(pid_t pid, Liste_Processus* liste_p);
// Changer l'état d'un processus en fonction de son pid 
void changer_etat(Liste_Processus* liste_p, pid_t pid, Etat_Processus etat);
// Supprimer un processus d'une liste de processus 
void supprimer(Liste_Processus* liste_p, pid_t pid);
// Ajouter un processus à la liste de processus
void ajouter(Liste_Processus* liste_p, Processus p);
// Vérifier si l'identifiant existe 
bool est_ident(Liste_Processus* liste_p, int ident);

#endif
