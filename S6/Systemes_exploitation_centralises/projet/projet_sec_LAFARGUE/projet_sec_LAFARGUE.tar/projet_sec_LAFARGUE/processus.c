#include "processus.h"

Processus nv_processus(Liste_Processus* l, pid_t pid, Etat_Processus etat, char* seq) {
	int ident = 0;
	for(int i=0; i < l->taille; i++) {
		if (ident < (l->l+i)->ident) { 
			ident = (l->l+i)->ident;
		}
	}
	ident++;
	Processus p = {.ident = ident, .pid = pid, .etat = etat, .commande = seq};
	return p;
}

pid_t idToPid(int ident, Liste_Processus* liste_p) {
	int indice = 0;
	int p_ident = liste_p->l->ident;
	while((liste_p->l+indice) != NULL && p_ident != ident && indice < liste_p->taille) {
		indice++;
		p_ident = (liste_p->l+indice)->ident;
	}
	pid_t pid = (liste_p->l+indice)->pid;
	return pid;
}

int pidToId(pid_t pid, Liste_Processus* liste_p) {
	int p_pid = liste_p->l->pid;
	int indice = 0;
	while((liste_p->l+indice) != NULL && p_pid != pid && indice < liste_p->taille) {
		indice++;
		p_pid = (liste_p->l+indice)->pid;
	}
	int ident = (liste_p->l+indice)->ident;
	return ident;
}

void changer_etat(Liste_Processus* liste_p, pid_t pid, Etat_Processus etat) {
	int indice = 0;
	while((liste_p->l+indice) != NULL && (liste_p->l+indice)->pid != pid && indice < liste_p->taille) {
		indice++;
	}
	(liste_p->l+indice)->etat = etat;
}

void supprimer(Liste_Processus* liste_p, pid_t pid) {
	int indice = 0;
	while((liste_p->l+indice) != NULL && (liste_p->l+indice)->pid != pid && indice < liste_p->taille) {
		indice++;
	}
	liste_p->l[indice] = liste_p->l[liste_p->taille - 1];
	liste_p->taille--;
}

void ajouter(Liste_Processus* liste_p, Processus p) {
	if (liste_p->taille == liste_p->capacite) {
		liste_p->capacite = liste_p->capacite *2;
		Processus* nv_liste = realloc(liste_p->l, liste_p->capacite *sizeof(Processus));
		if (nv_liste == NULL) {
			perror("erreur realloc");
			exit(4);
		}
		liste_p->l = nv_liste;
	}
	liste_p->l[liste_p->taille] = p;
	liste_p->taille++;
}

bool est_ident(Liste_Processus* liste_p, int ident) {
	bool res = false;
	int indice = 0;
	while((liste_p->l+indice) != NULL && !res && indice < liste_p->taille) {
		if (ident == (liste_p->l+indice)->ident) {
			res = true;
		}
		indice++;
	}
	return res;	
}

