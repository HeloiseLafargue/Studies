#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* primitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <sys/wait.h> /* wait */
#include "readcmd.h" 
#include "readcmd.c"
#include "cmdint.h"
#include "processus.h"
#include "cmdint.c"
#include "processus.c"
#include <stdbool.h>
#include <string.h>
#include <stddef.h>
#include <errno.h>
#include <malloc.h>
#include <fcntl.h>

typedef struct cmdline cmdline;

int main(int argc, char *argv[]) {

	cmdline* cmd;
	int codeTerm;

	while(1) {
		printf("shell$");
		do {
			cmd = readcmd();
		} while(cmd == NULL);

		if (cmd->err != NULL) {
			printf("Erreur : %s", cmd->err);
		}
		if(*cmd->seq != NULL) {
			pid_t pidFils = fork();
		    if (pidFils == 0) {
				int errExec = execvp(cmd->seq[0][0], cmd->seq[0]);
				if (errExec == -1) {
					perror("Erreur execution");
					exit(2);
				}
			} else if (pidFils < 0) {
				perror("Erreur fork");
				exit(1);	
			} else {
				// QUESTION 3
				int idFils = wait(&codeTerm);
				if (idFils == -1) { perror("Erreur wait"); exit(3); }
			}
		}
	}
	return EXIT_SUCCESS;
}

