#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* primitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <sys/wait.h> /* wait */
#include <string.h> /* pour utiliser la commande strcmp */
#include "readcmd.h" 
#include "readcmd.c"
#include "cmdint.h"
#include "processus.h"
#include "cmdint.c"
#include "processus.c"
#include <stdbool.h>
#include <stddef.h>
#include <errno.h>
#include <malloc.h>
#include <fcntl.h>

typedef struct cmdline cmdline;

int main(int argc, char *argv[]) {

	cmdline* cmd;
	int codeTerm;

	while(1) {
		printf("shell$");
		do {
			cmd = readcmd();
		} while(cmd == NULL);
		if (cmd->err != NULL) {
			printf("Erreur : %s", cmd->err);
		}
		if(*cmd->seq != NULL) {
			if (strcmp(cmd->seq[0][0], "cd") == 0) {
				chdir(cmd->seq[0][1]);

			} else if (strcmp(cmd->seq[0][0], "exit") == 0) {
				exit(0);
			// QUESTION 5
			} else if (cmd->backgrounded != NULL) {
				pid_t pidFilsBack = fork();
				if (pidFilsBack < 0) {
					perror("Erreur fork");
					exit(1);
				} else if (pidFilsBack == 0) {
					int err = execvp(cmd->seq[0][0], cmd->seq[0]);
					if (err == -1) { perror("Erreur execution"); exit(4); }
				}
			}
			//
			else {
				pid_t pidFils = fork();
				if (pidFils == 0) {
					int errExec = execvp(cmd->seq[0][0], cmd->seq[0]);
					if (errExec == -1) {
						perror("Erreur execution");
						exit(2);
					}
				} else if (pidFils < 0) {
					perror("erreur fork");
					exit(1);
				} else {
					int idFils = wait(&codeTerm);
					if (idFils == -1) { perror("Erreur wait"); exit(3); }
				}
			}
		}
	}
	return EXIT_SUCCESS;
}



