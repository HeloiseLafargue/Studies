#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* primitives de base : fork, ...*/
#include <stdlib.h>   /* exit */
#include <sys/wait.h> /* wait */
#include <string.h> /* pour utiliser la commande strcmp */
#include "readcmd.h" 
#include "readcmd.c"
#include <pwd.h> /* pour utiliser la commande getpwuid */



int main (void){
    int __stat_loc;
    int boucle=1;
    while (boucle==1) {
        printf("shell$");
        struct cmdline * lecture = readcmd();
        if ( !strcmp("exit",lecture->seq[0][0])){
            boucle =0;
        } 
        else if (!strcmp("cd",lecture->seq[0][0])){
                if (lecture->seq[0][1] !=NULL) {
                    chdir(lecture->seq[0][1]);
                } else {
                    chdir(getpwuid(getuid())->pw_dir);
                }
        }
        int pidFils = fork ();
        if ( pidFils == -1) {
                    printf ( " Erreur fork \ n " );
                    exit (1);
        } else if ( pidFils == 0) { /* fils */
                    execvp(lecture->seq[0][0],lecture->seq[0]);  
        } else {
                    if (lecture->backgrounded !=NULL) {
                            int pidFilsD = fork();
                            if (pidFilsD == -1) {
                                    printf(" Erreur fork \ n ");
                                    exit(2);
                            } else {
                                    execvp(lecture->seq[0][0], lecture->seq[0]);
                            }


       }
       }
}
}
